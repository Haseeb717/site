/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","eo",{loadError:"Eraro okazis dum la dosiera legado.",networkError:"Reta eraro okazis dum la dosiera al\u015duto.",httpError404:"HTTP eraro okazis dum la dosiera al\u015duto (404: dosiero ne trovita).",httpError403:"HTTP eraro okazis dum la dosiera al\u015duto (403: malpermesita).",httpError:"HTTP eraro okazis dum la dosiera al\u015duto (erara stato: %1).",noUrlError:"Al\u015duta URL ne estas difinita.",responseError:"Mal\u011dusta respondo de la servilo."});