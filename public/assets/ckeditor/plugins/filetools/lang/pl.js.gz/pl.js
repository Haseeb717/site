/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","pl",{loadError:"B\u0142\u0105d podczas odczytu pliku.",networkError:"W trakcie wysy\u0142ania pliku pojawi\u0142 si\u0119 b\u0142\u0105d sieciowy.",httpError404:"B\u0142\u0105d HTTP w trakcie wysy\u0142ania pliku (404: Nie znaleziono pliku).",httpError403:"B\u0142\u0105d HTTP w trakcie wysy\u0142ania pliku (403: Zabroniony).",httpError:"B\u0142\u0105d HTTP w trakcie wysy\u0142ania pliku (status b\u0142\u0119du: %1).",noUrlError:"Nie zdefiniowano adresu URL do przes\u0142ania pliku.",responseError:"Niepoprawna odpowied\u017a serwera."});