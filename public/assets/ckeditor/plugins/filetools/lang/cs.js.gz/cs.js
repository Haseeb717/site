/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","cs",{loadError:"P\u0159i \u010dten\xed souboru do\u0161lo k chyb\u011b.",networkError:"P\u0159i nahr\xe1v\xe1n\xed souboru do\u0161lo k chyb\u011b v s\xedti.",httpError404:"P\u0159i nahr\xe1v\xe1n\xed souboru do\u0161lo k chyb\u011b HTTP (404: Soubor nenalezen).",httpError403:"P\u0159i nahr\xe1v\xe1n\xed souboru do\u0161lo k chyb\u011b HTTP (403: Zak\xe1z\xe1no).",httpError:"P\u0159i nahr\xe1v\xe1n\xed souboru do\u0161lo k chyb\u011b HTTP (chybov\xfd stav: %1).",noUrlError:"URL pro nahr\xe1n\xed nen\xed zad\xe1na.",responseError:"Nespr\xe1vn\xe1 odpov\u011b\u010f serveru."});