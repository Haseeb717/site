/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","tr",{loadError:"Dosya okunurken hata olu\u015ftu.",networkError:"Dosya g\xf6nderilirken a\u011f hatas\u0131 olu\u015ftu.",httpError404:"Dosya g\xf6nderilirken HTTP hatas\u0131 olu\u015ftu (404: Dosya bulunamad\u0131).",httpError403:"Dosya g\xf6nderilirken HTTP hatas\u0131 olu\u015ftu (403: Yasakl\u0131).",httpError:"Dosya g\xf6nderilirken HTTP hatas\u0131 olu\u015ftu (hata durumu: %1).",noUrlError:"G\xf6nderilecek URL belirtilmedi.",responseError:"Sunucu cevap veremedi."});