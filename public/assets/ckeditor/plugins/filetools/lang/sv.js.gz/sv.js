/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","sv",{loadError:"Fel uppstod vid fill\xe4sning",networkError:"N\xe4tverksfel uppstod vid filuppladdning.",httpError404:"HTTP-fel uppstod vid filuppladdning (404: Fil hittades inte).",httpError403:"HTTP-fel uppstod vid filuppladdning (403: F\xf6rbjuden).",httpError:"HTTP-fel uppstod vid filuppladdning (felstatus: %1).",noUrlError:"URL f\xf6r uppladdning inte definierad.",responseError:"Felaktigt serversvar."});