/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","de",{loadError:"W\xe4hrend dem Lesen der Datei ist ein Fehler aufgetreten.",networkError:"W\xe4hrend dem Hochladen der Datei ist ein Netzwerkfehler aufgetreten.",httpError404:"W\xe4hrend dem Hochladen der Datei ist ein HTTP-Fehler aufgetreten (404: Datei nicht gefunden).",httpError403:"W\xe4hrend dem Hochladen der Datei ist ein HTTP-Fehler aufgetreten (403: Verboten).",httpError:"W\xe4hrend dem Hochladen der Datei ist ein HTTP-Fehler aufgetreten (Fehlerstatus: %1).",noUrlError:"Hochlade-URL ist nicht definiert.",responseError:"Falsche Antwort des Servers."});