/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","no",{title:"Elementinformasjon",dialogName:"Navn p\xe5 dialogvindu",tabName:"Navn p\xe5 fane",elementId:"Element-ID",elementType:"Elementtype"});