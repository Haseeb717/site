/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","pt-br",{title:"Informa\xe7\xe3o do Elemento",dialogName:"Nome da janela de di\xe1logo",tabName:"Nome da aba",elementId:"ID do Elemento",elementType:"Tipo do elemento"});