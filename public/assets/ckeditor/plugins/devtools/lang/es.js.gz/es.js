/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","es",{title:"Informaci\xf3n del Elemento",dialogName:"Nombre de la ventana de di\xe1logo",tabName:"Nombre de la pesta\xf1a",elementId:"ID del Elemento",elementType:"Tipo del elemento"});