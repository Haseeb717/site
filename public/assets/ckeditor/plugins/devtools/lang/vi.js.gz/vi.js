/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","vi",{title:"Th\xf4ng tin th\xe0nh ph",dialogName:"T\xean h\u1ed9p tho",tabName:"T\xean th",elementId:"M\xe3 th\xe0nh ph",elementType:"Lo\u1ea1i th\xe0nh ph"});