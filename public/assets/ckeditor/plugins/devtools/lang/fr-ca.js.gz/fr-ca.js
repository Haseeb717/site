/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","fr-ca",{title:"Information de l'\xe9l\xe9ment",dialogName:"Nom de la fen\xeatre",tabName:"Nom de l'onglet",elementId:"ID de l'\xe9l\xe9ment",elementType:"Type de l'\xe9l\xe9ment"});