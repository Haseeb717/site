/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ko",{title:"\uad6c\uc131 \uc694\uc18c \uc815\ubcf4",dialogName:"\ub2e4\uc774\uc5bc\ub85c\uadf8 \uc708\ub3c4\uc6b0 \uc774\ub984",tabName:"\ud0ed \uc774\ub984",elementId:"\uc694\uc18c ID",elementType:"\uc694\uc18c \ud615\uc2dd"});