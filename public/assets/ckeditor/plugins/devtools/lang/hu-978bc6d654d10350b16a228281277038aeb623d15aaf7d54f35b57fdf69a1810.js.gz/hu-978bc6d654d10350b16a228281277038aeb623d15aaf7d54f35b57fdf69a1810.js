/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","hu",{title:"Elem inform\xe1ci\xf3",dialogName:"P\xe1rbesz\xe9dablak neve",tabName:"F\xfcl neve",elementId:"Elem ID",elementType:"Elem t\xedpusa"});