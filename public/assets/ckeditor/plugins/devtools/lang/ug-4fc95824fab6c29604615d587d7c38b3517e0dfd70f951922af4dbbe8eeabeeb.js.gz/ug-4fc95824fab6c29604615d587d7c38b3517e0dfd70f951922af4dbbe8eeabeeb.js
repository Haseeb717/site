/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ug",{title:"\u0626\u06d0\u0644\u06d0\u0645\u06d0\u0646\u062a \u0626\u06c7\u0686\u06c7\u0631\u0649",dialogName:"\u0633\u06c6\u0632\u0644\u06d5\u0634\u0643\u06c8 \u0643\u06c6\u0632\u0646\u06d5\u0643 \u0626\u0627\u062a\u0649",tabName:"Tab \u0626\u0627\u062a\u0649",elementId:"\u0626\u06d0\u0644\u06d0\u0645\u06d0\u0646\u062a \u0643\u0649\u0645\u0644\u0649\u0643\u0649",elementType:"\u0626\u06d0\u0644\u06d0\u0645\u06d0\u0646\u062a \u062a\u0649\u067e\u0649"});