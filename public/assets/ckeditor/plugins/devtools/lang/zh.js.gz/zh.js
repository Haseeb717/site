/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","zh",{title:"\u5143\u4ef6\u8cc7\u8a0a",dialogName:"\u5c0d\u8a71\u8996\u7a97\u540d\u7a31",tabName:"\u6a19\u7c64\u540d\u7a31",elementId:"\u5143\u4ef6 ID",elementType:"\u5143\u4ef6\u985e\u578b"});