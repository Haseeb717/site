/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ku",{title:"\u0632\u0627\u0646\u06cc\u0627\u0631\u06cc \u062a\u0648\u062e\u0645",dialogName:"\u0646\u0627\u0648\u06cc \u067e\u06d5\u0646\u062c\u06d5\u0631\u06d5\u06cc \u062f\u06cc\u0627\u0644\u06c6\u06af",tabName:"\u0646\u0627\u0648\u06cc \u0628\u0627\u0632\u062f\u06d5\u0631 \u062a\u0627\u0628",elementId:"\u0646\u0627\u0633\u0646\u0627\u0645\u06d5\u06cc \u062a\u0648\u062e\u0645",elementType:"\u062c\u06c6\u0631\u06cc \u062a\u0648\u062e\u0645"});