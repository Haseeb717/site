/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","pt",{title:"Informa\xe7\xe3o do elemento",dialogName:"Nome da janela de di\xe1logo",tabName:"Nome do separador",elementId:"ID do elemento",elementType:"Tipo de Elemento"});