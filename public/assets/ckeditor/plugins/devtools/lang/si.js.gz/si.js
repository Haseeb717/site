/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","si",{title:"\u0db8\u0dd4\u0dbd\u0daf\u0dca\u200d\u0dbb\u0dc0\u0dca\u200d\u0dba ",dialogName:"\u0daf\u0dd9\u0db6\u0dc3\u0dca \u0d9a\u0dc0\u0dd4\u0dc5\u0dd4\u0dc0\u0dda \u0db1\u0db8",tabName:"\u0dad\u0dd3\u0dbb\u0dd4\u0dc0\u0dda \u0db1\u0db8",elementId:"\u0db8\u0dd4\u0dbd\u0daf\u0dca\u200d\u0dbb\u0dc0\u0dca\u200d\u0dba \u0d9a\u0dda\u0dad\u0dba",elementType:"\u0db8\u0dd4\u0dbd\u0daf\u0dca\u200d\u0dbb\u0dc0\u0dca\u200d\u0dba \u0dc0\u0dbb\u0dca\u0d9c\u0dba"});