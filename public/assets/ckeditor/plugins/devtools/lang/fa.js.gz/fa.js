/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","fa",{title:"\u0627\u0637\u0644\u0627\u0639\u0627\u062a \u0639\u0646\u0635\u0631",dialogName:"\u0646\u0627\u0645 \u067e\u0646\u062c\u0631\u0647 \u0645\u062d\u0627\u0648\u0631\u0647\u200c\u0627\u06cc",tabName:"\u0646\u0627\u0645 \u0628\u0631\u06af\u0647",elementId:"ID \u0639\u0646\u0635\u0631",elementType:"\u0646\u0648\u0639 \u0639\u0646\u0635\u0631"});