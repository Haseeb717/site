/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","fr",{title:"Information sur l'\xe9l\xe9ment",dialogName:"Nom de la fen\xeatre de dialogue",tabName:"Nom de l'onglet",elementId:"ID de l'\xe9l\xe9ment",elementType:"Type de l'\xe9l\xe9ment"});