/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","he",{title:"\u05de\u05d9\u05d3\u05e2 \u05e2\u05dc \u05d4\u05d0\u05dc\u05de\u05e0\u05d8",dialogName:"\u05e9\u05dd \u05d4\u05d3\u05d9\u05d0\u05dc\u05d5\u05d2",tabName:"\u05e9\u05dd \u05d4\u05d8\u05d0\u05d1",elementId:"ID \u05e9\u05dc \u05d4\u05d0\u05dc\u05de\u05e0\u05d8",elementType:"\u05e1\u05d5\u05d2 \u05d4\u05d0\u05dc\u05de\u05e0\u05d8"});