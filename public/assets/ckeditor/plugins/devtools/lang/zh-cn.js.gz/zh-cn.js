/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","zh-cn",{title:"\u5143\u7d20\u4fe1\u606f",dialogName:"\u5bf9\u8bdd\u6846\u7a97\u53e3\u540d\u79f0",tabName:"\u9009\u9879\u5361\u540d\u79f0",elementId:"\u5143\u7d20 ID",elementType:"\u5143\u7d20\u7c7b\u578b"});