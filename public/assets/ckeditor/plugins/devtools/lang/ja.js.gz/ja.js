/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ja",{title:"\u30a8\u30ec\u30e1\u30f3\u30c8\u60c5\u5831",dialogName:"\u30c0\u30a4\u30a2\u30ed\u30b0\u30a6\u30a3\u30f3\u30c9\u30a6\u540d",tabName:"\u30bf\u30d6\u540d",elementId:"\u30a8\u30ec\u30e1\u30f3\u30c8ID",elementType:"\u8981\u7d20\u30bf\u30a4\u30d7"});