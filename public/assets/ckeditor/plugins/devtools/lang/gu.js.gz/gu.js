/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","gu",{title:"\u0aaa\u0acd\u0ab0\u0abe\u0aa5\u0aae\u0abf\u0a95 \u0aae\u0abe\u0ab9\u0abf\u0aa4\u0ac0",dialogName:"\u0ab5\u0abf\u0aa8\u0acd\u0aa1\u0acb\u0aa8\u0ac1\u0a82 \u0aa8\u0abe\u0aae",tabName:"\u0a9f\u0ac7\u0aac\u0aa8\u0ac1\u0a82 \u0aa8\u0abe\u0aae",elementId:"\u0aaa\u0acd\u0ab0\u0abe\u0aa5\u0aae\u0abf\u0a95 \u0a86\u0a88\u0aa1\u0ac0",elementType:"\u0aaa\u0acd\u0ab0\u0abe\u0aa5\u0aae\u0abf\u0a95 \u0aaa\u0acd\u0ab0\u0a95\u0abe\u0ab0"});