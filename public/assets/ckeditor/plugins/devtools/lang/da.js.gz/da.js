/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","da",{title:"Information p\xe5 elementet",dialogName:"Dialogboks",tabName:"Tab beskrivelse",elementId:"ID p\xe5 element",elementType:"Type af element"});