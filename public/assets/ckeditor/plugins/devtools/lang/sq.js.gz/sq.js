/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","sq",{title:"T\xeb dh\xebnat e elementit",dialogName:"Emri i dritares s\xeb dialogut",tabName:"Emri i flet\xebs",elementId:"ID e elementit",elementType:"Lloji i elementit"});