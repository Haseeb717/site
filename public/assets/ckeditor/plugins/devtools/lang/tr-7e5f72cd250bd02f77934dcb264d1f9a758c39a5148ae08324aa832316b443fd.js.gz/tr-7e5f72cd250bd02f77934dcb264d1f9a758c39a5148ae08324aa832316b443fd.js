/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","tr",{title:"Eleman Bilgisi",dialogName:"\u0130leti\u015fim pencere ismi",tabName:"Sekme ad\u0131",elementId:"Eleman ID",elementType:"Eleman t\xfcr\xfc"});