/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","gl",{title:"Informaci\xf3n do elemento",dialogName:"Nome da xanela de di\xe1logo",tabName:"Nome da lapela",elementId:"ID do elemento",elementType:"Tipo do elemento"});