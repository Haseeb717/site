/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","sk",{title:"Inform\xe1cie o prvku",dialogName:"N\xe1zov okna dial\xf3gu",tabName:"N\xe1zov z\xe1lo\u017eky",elementId:"ID prvku",elementType:"Typ prvku"});