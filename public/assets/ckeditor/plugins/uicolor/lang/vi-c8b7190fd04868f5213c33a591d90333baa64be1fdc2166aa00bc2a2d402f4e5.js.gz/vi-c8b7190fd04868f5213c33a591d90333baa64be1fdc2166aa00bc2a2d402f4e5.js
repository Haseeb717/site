/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","vi",{title:"Giao di\u1ec7n ng\u01b0\u1eddi d\xf9ng Color Picker",preview:"Xem tr\u01b0\u1edbc tr\u1ef1c ti\u1ebfp",config:"D\xe1n chu\u1ed7i n\xe0y v\xe0o t\u1eadp tin config.js c\u1ee7a b\u1ea1n",predefined:"T\u1eadp m\xe0u \u0111\u1ecbnh ngh\u0129a s\u1eb5n"});