/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","hu",{title:"UI Sz\xednv\xe1laszt\xf3",preview:"\xc9l\u0151 el\u0151n\xe9zet",config:"Illessze be ezt a sz\xf6veget a config.js f\xe1jlba",predefined:"El\u0151re defini\xe1lt sz\xednbe\xe1ll\xedt\xe1sok"});