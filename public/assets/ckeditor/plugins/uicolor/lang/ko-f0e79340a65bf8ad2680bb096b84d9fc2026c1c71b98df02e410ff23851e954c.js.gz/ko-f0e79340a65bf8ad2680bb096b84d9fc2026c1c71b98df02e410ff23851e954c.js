/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ko",{title:"UI \uc0c9\uc0c1 \uc120\ud0dd\uae30",preview:"\ubbf8\ub9ac\ubcf4\uae30",config:"\uc774 \ubb38\uc790\uc5f4\uc744 config.js \uc5d0 \ubd99\uc5ec\ub123\uc73c\uc138\uc694",predefined:"\ubbf8\ub9ac \uc815\uc758\ub41c \uc0c9\uc0c1"});