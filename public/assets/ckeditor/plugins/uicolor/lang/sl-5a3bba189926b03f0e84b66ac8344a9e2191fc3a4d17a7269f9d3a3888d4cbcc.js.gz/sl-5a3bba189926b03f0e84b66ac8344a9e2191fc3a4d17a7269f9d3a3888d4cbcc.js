/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sl",{title:"UI Izbiralec Barve",preview:"\u017divi predogled",config:"Prilepite ta niz v va\u0161o config.js datoteko",predefined:"Vnaprej dolo\u010deni barvni kompleti"});