/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","zh",{title:"UI \u8272\u5f69\u9078\u64c7\u5668",preview:"\u5373\u6642\u9810\u89bd",config:"\u8acb\u5c07\u6b64\u6bb5\u5b57\u4e32\u8907\u88fd\u5230\u60a8\u7684 config.js \u6a94\u6848\u4e2d\u3002",predefined:"\u8a2d\u5b9a\u9810\u5148\u5b9a\u7fa9\u7684\u8272\u5f69"});