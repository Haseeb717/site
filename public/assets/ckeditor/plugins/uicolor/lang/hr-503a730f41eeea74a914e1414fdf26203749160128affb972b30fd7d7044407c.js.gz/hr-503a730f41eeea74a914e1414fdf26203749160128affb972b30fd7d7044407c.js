/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","hr",{title:"UI odabir boja",preview:"Pregled u\u017eivo",config:"Zalijepite ovaj tekst u Va\u0161u config.js datoteku.",predefined:"Ve\u0107 postavljeni setovi boja"});