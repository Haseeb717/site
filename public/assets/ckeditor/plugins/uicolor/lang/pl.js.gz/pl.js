/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","pl",{title:"Wyb\xf3r koloru interfejsu",preview:"Podgl\u0105d na \u017cywo",config:"Wklej poni\u017cszy \u0142a\u0144cuch znak\xf3w do pliku config.js:",predefined:"Predefiniowane zestawy kolor\xf3w"});