/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","tr",{title:"UI Renk Se\xe7ici",preview:"Canl\u0131 \xf6n izleme",config:"Bu yaz\u0131y\u0131 config.js dosyas\u0131n\u0131n i\xe7ine yap\u0131\u015ft\u0131r\u0131n",predefined:"\xd6nceden tan\u0131ml\u0131 renk seti"});