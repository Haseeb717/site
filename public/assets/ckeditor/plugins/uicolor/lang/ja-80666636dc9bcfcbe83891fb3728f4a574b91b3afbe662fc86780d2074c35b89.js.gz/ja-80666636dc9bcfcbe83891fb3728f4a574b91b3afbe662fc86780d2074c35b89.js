/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ja",{title:"UI\u30ab\u30e9\u30fc\u30d4\u30c3\u30ab\u30fc",preview:"\u30e9\u30a4\u30d6\u30d7\u30ec\u30d3\u30e5\u30fc",config:"\u3053\u306e\u6587\u5b57\u5217\u3092 config.js \u30d5\u30a1\u30a4\u30eb\u3078\u8cbc\u308a\u4ed8\u3051",predefined:"\u65e2\u5b9a\u30ab\u30e9\u30fc\u30bb\u30c3\u30c8"});