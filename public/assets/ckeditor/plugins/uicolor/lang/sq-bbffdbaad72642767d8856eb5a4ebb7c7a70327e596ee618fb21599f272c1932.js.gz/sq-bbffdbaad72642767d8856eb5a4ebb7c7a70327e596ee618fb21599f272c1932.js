/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sq",{title:"UI Mbledh\xebs i Ngjyrave",preview:"Parapamje direkte",config:"Hidhni k\xebt\xeb varg n\xeb sked\xebn tuaj config.js",predefined:"Setet e paradefinuara t\xeb ngjyrave"});