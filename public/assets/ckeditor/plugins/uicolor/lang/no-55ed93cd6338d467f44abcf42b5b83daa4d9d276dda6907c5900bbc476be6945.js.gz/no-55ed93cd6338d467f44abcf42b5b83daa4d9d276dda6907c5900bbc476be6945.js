/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","no",{title:"Fargevelger for brukergrensesnitt",preview:"Forh\xe5ndsvisning i sanntid",config:"Lim inn f\xf8lgende tekst i din config.js-fil",predefined:"Forh\xe5ndsdefinerte fargesett"});