/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","fi",{title:"K\xe4ytt\xf6liittym\xe4n v\xe4ripaletti",preview:"Esikatsele heti",config:"Liit\xe4 t\xe4m\xe4 merkkijono config.js tiedostoosi",predefined:"Esim\xe4\xe4ritellyt v\xe4rijoukot"});