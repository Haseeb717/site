/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","lv",{title:"UI kr\u0101sas izv\u0113le",preview:"Priek\u0161skat\u012bjums",config:"Iel\u012bm\u0113jiet \u0161o rindu j\u016bsu config.js fail\u0101",predefined:"Predefin\u0113ti kr\u0101su komplekti"});