/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sk",{title:"UI v\xfdber farby",preview:"\u017div\xfd n\xe1h\u013ead",config:"Vlo\u017ete tento re\u0165azec do v\xe1\u0161ho config.js s\xfaboru",predefined:"Preddefinovan\xe9 sady farieb"});