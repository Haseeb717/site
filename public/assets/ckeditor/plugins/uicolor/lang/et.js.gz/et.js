/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","et",{title:"V\xe4rvivalija kasutajaliides",preview:"Automaatne eelvaade",config:"Aseta see s\xf5ne oma config.js faili.",predefined:"Eelm\xe4\xe4ratud v\xe4rvikomplektid"});