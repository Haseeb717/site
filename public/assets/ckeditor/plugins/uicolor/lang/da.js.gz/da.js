/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","da",{title:"Brugerflade p\xe5 farvev\xe6lger",preview:"Vis liveeksempel",config:"Inds\xe6t denne streng i din config.js fil",predefined:"Pr\xe6definerede farveskemaer"});