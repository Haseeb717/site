/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","zh-cn",{title:"\u7528\u6237\u754c\u9762\u989c\u8272\u9009\u62e9\u5668",preview:"\u5373\u65f6\u9884\u89c8",config:"\u7c98\u8d34\u6b64\u5b57\u7b26\u4e32\u5230\u60a8\u7684 config.js \u6587\u4ef6",predefined:"\u9884\u5b9a\u4e49\u989c\u8272\u96c6"});