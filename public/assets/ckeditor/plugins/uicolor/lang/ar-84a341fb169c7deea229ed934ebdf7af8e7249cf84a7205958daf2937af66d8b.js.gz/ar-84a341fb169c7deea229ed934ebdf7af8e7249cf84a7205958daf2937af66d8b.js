/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ar",{title:"\u0645\u0646\u062a\u0642\u064a \u0627\u0644\u0623\u0644\u0648\u0627\u0646",preview:"\u0645\u0639\u0627\u064a\u0646\u0629 \u0645\u0628\u0627\u0634\u0631\u0629",config:"\u0642\u0635 \u0627\u0644\u0633\u0637\u0631 \u0625\u0644\u0649 \u0627\u0644\u0645\u0644\u0641 config.js",predefined:"\u0645\u062c\u0645\u0648\u0639\u0627\u062a \u0623\u0644\u0648\u0627\u0646 \u0645\u0639\u0631\u0641\u0629 \u0645\u0633\u0628\u0642\u0627"});