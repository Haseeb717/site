/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","cs",{title:"V\xfdb\u011br barvy rozhran\xed",preview:"\u017div\xfd n\xe1hled",config:"Vlo\u017ete tento \u0159et\u011bzec do va\u0161eho souboru config.js",predefined:"P\u0159ednastaven\xe9 sady barev"});