/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sv",{title:"UI F\xe4rgv\xe4ljare",preview:"Live f\xf6rhandsgranskning",config:"Klistra in den h\xe4r str\xe4ngen i din config.js-fil",predefined:"F\xf6rdefinierade f\xe4rgupps\xe4ttningar"});