/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ug",{button:"\u0643\u0648\u062f \u067e\u0627\u0631\u0686\u0649\u0633\u0649 \u0642\u0649\u0633\u062a\u06c7\u0631\u06c7\u0634",codeContents:"Code content",emptySnippetError:"A code snippet cannot be empty.",language:"Language",title:"Code snippet",pathName:"code snippet"});