/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","sv",{button:"Infoga kodsnutt",codeContents:"Kodinneh\xe5lll",emptySnippetError:"Inneh\xe5ll kr\xe4vs f\xf6r kodsnutt",language:"Spr\xe5k",title:"Kodsnutt",pathName:"kodsnutt"});