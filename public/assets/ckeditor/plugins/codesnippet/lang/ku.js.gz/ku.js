/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ku",{button:"\u062a\u06ce\u062e\u0633\u062a\u0646\u06cc \u062a\u06cc\u062a\u06a9\u06cc \u06a9\u06c6\u062f",codeContents:"\u0646\u0627\u0648\u06d5\u0695\u06c6\u06a9\u06cc \u06a9\u06c6\u062f",emptySnippetError:"\u062a\u06cc\u062a\u06a9\u06cc \u06a9\u06c6\u062f \u0646\u0627\u0628\u06ce\u062a \u0628\u06d5\u062a\u0627\u06b5 \u0628\u06ce\u062a.",language:"\u0632\u0645\u0627\u0646",title:"\u062a\u06cc\u062a\u06a9\u06cc \u06a9\u06c6\u062f",pathName:"\u062a\u06cc\u062a\u06a9\u06cc \u06a9\u06c6\u062f"});