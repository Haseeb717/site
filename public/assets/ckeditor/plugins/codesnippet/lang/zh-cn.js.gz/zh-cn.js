/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","zh-cn",{button:"\u63d2\u5165\u4ee3\u7801\u6bb5",codeContents:"\u4ee3\u7801\u5185\u5bb9",emptySnippetError:"\u63d2\u5165\u7684\u4ee3\u7801\u4e0d\u80fd\u4e3a\u7a7a\u3002",language:"\u4ee3\u7801\u8bed\u8a00",title:"\u4ee3\u7801\u6bb5",pathName:"\u4ee3\u7801\u6bb5"});