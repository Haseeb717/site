/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","fi",{button:"Lis\xe4\xe4 koodileike",codeContents:"Koodisis\xe4lt\xf6",emptySnippetError:"Koodileike ei voi olla tyhj\xe4.",language:"Kieli",title:"Koodileike",pathName:"koodileike"});