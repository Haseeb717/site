/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","km",{button:"Insert Code Snippet",codeContents:"\u1798\u17b6\u178f\u17b7\u1780\u17b6\u1780\u17bc\u178a",emptySnippetError:"A code snippet cannot be empty.",language:"\u1797\u17b6\u179f\u17b6",title:"Code snippet",pathName:"code snippet"});