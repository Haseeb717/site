/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","tt",{button:"\u041a\u043e\u0434 \u04e9\u0437\u0435\u0433\u0435\u043d \u04e9\u0441\u0442\u04d9\u04af",codeContents:"\u041a\u043e\u0434 \u044d\u0447\u0442\u04d9\u043b\u0435\u0433\u0435",emptySnippetError:"\u041a\u043e\u0434 \u04e9\u0437\u0435\u0433\u0435 \u0431\u0443\u0448 \u0431\u0443\u043b\u043c\u0430\u0441\u043a\u0430 \u0442\u0438\u0435\u0448.",language:"\u0422\u0435\u043b",title:"\u041a\u043e\u0434 \u04e9\u0437\u0435\u0433\u0435",pathName:"\u043a\u043e\u0434 \u04e9\u0437\u0435\u0433\u0435"});