/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","eo",{button:"Enmeti koda\u0135eron",codeContents:"Kodenhavo",emptySnippetError:"Koda\u0135ero ne povas esti malplena.",language:"Lingvo",title:"Koda\u0135ero",pathName:"koda\u0135ero"});