/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","gl",{button:"Inserir fragmento de c\xf3digo",codeContents:"Contido do c\xf3digo",emptySnippetError:"Un fragmento de c\xf3digo non pode estar baleiro.",language:"Linguaxe",title:"Fragmento de c\xf3digo",pathName:"fragmento de c\xf3digo"});