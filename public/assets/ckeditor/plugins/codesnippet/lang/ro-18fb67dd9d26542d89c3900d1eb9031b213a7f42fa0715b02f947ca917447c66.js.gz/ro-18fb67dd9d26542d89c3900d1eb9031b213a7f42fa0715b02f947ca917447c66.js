/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ro",{button:"Adaug\u0103 segment de cod",codeContents:"Con\u021binutul codului",emptySnippetError:"Un segment de cod nu poate fi gol.",language:"Limba",title:"Segment de cod",pathName:"segment de cod"});