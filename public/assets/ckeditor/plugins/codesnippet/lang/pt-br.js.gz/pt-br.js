/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","pt-br",{button:"Inserir fragmento de c\xf3digo",codeContents:"Conte\xfado do c\xf3digo",emptySnippetError:"Um fragmento de c\xf3digo n\xe3o pode ser vazio",language:"Idioma",title:"Fragmento de c\xf3digo",pathName:"fragmento de c\xf3digo"});