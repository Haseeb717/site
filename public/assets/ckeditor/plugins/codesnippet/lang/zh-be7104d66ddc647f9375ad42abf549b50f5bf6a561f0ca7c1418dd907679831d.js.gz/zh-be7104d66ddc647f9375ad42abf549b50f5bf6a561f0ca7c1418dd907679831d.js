/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","zh",{button:"\u63d2\u5165\u7a0b\u5f0f\u78bc\u7247\u6bb5",codeContents:"\u7a0b\u5f0f\u78bc\u5167\u5bb9",emptySnippetError:"\u7a0b\u5f0f\u78bc\u7247\u6bb5\u4e0d\u53ef\u70ba\u7a7a\u767d\u3002",language:"\u8a9e\u8a00",title:"\u7a0b\u5f0f\u78bc\u7247\u6bb5",pathName:"\u7a0b\u5f0f\u78bc\u7247\u6bb5"});