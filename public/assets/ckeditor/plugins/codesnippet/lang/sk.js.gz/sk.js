/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","sk",{button:"Vlo\u017ete k\xf3d Snippet-u",codeContents:"Obsah k\xf3du",emptySnippetError:"Snippet k\xf3du nesmie by\u0165 pr\xe1zdny.",language:"Jazyk",title:"Snippet k\xf3du",pathName:"snippet k\xf3du"});