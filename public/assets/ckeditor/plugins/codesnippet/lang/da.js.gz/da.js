/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","da",{button:"Inds\xe6t kodestykket her",codeContents:"Koden",emptySnippetError:"Kodestykket kan ikke v\xe6re tomt.",language:"Sprog",title:"Kodestykke",pathName:"kodestykke"});