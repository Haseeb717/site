/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","vi",{button:"Ch\xe8n \u0111o\u1ea1n m\xe3",codeContents:"N\u1ed9i dung m\xe3",emptySnippetError:"M\u1ed9t \u0111o\u1ea1n m\xe3 kh\xf4ng th\u1ec3 \u0111\u1ec3 tr\u1ed1ng.",language:"Ng\xf4n ng\u1eef",title:"\u0110o\u1ea1n m\xe3",pathName:"m\xe3 d\xednh"});