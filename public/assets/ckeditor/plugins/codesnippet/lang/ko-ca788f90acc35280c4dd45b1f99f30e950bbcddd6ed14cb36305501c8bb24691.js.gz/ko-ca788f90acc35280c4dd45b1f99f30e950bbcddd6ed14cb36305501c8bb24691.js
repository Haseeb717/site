/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ko",{button:"\ucf54\ub4dc \uc2a4\ub2c8\ud3ab \uc0bd\uc785",codeContents:"\ucf54\ub4dc \ubcf8\ubb38",emptySnippetError:"\ucf54\ub4dc \uc2a4\ub2c8\ud3ab\uc740 \ube48\uce78\uc77c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.",language:"\uc5b8\uc5b4",title:"\ucf54\ub4dc \uc2a4\ub2c8\ud3ab",pathName:"\ucf54\ub4dc \uc2a4\ub2c8\ud3ab"});