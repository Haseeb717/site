/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","tr",{button:"Kod par\xe7ac\u0131\u011f\u0131 ekle",codeContents:"Kod",emptySnippetError:"Kod par\xe7ac\u0131\u011f\u0131 bo\u015f b\u0131rak\u0131lamaz",language:"Dil",title:"Kod par\xe7ac\u0131\u011f\u0131",pathName:"kod par\xe7ac\u0131\u011f\u0131"});