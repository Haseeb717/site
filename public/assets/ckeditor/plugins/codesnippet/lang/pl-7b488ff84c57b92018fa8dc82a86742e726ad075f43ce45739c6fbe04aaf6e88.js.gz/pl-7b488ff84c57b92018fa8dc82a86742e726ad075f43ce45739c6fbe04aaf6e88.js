/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","pl",{button:"Wstaw fragment kodu",codeContents:"Tre\u015b\u0107 kodu",emptySnippetError:"Kod nie mo\u017ce by\u0107 pusty.",language:"J\u0119zyk",title:"Fragment kodu",pathName:"fragment kodu"});