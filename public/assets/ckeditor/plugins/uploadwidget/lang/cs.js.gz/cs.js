/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","cs",{abort:"Nahr\xe1v\xe1n\xed zru\u0161eno u\u017eivatelem.",doneOne:"Soubor \xfasp\u011b\u0161n\u011b nahr\xe1n.",doneMany:"\xdasp\u011b\u0161n\u011b nahr\xe1no %1 soubor\u016f.",uploadOne:"Nahr\xe1v\xe1n\xed souboru ({percentage}%)...",uploadMany:"Nahr\xe1v\xe1n\xed soubor\u016f, {current} z {max} hotovo ({percentage}%)..."});