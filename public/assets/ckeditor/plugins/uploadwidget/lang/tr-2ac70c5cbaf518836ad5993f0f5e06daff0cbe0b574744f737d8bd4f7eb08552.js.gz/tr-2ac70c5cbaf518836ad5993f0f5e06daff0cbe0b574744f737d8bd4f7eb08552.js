/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","tr",{abort:"G\xf6nderme i\u015flemi kullan\u0131c\u0131 taraf\u0131ndan durduruldu.",doneOne:"G\xf6nderim i\u015flemi ba\u015far\u0131l\u0131 \u015fekilde tamamland\u0131.",doneMany:"%1 dosya ba\u015far\u0131l\u0131 \u015fekilde g\xf6nderildi.",uploadOne:"Dosyan\u0131n ({percentage}%) g\xf6nderildi...",uploadMany:"Toplam {current} / {max} dosyan\u0131n ({percentage}%) g\xf6nderildi..."});