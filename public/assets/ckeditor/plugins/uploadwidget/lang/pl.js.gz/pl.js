/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","pl",{abort:"Wysy\u0142anie przerwane przez u\u017cytkownika.",doneOne:"Plik zosta\u0142 pomy\u015blnie wys\u0142any.",doneMany:"Pomy\u015blnie wys\u0142ane pliki: %1.",uploadOne:"Wysy\u0142anie pliku ({percentage}%)...",uploadMany:"Wysy\u0142anie plik\xf3w, gotowe {current} z {max} ({percentage}%)..."});