/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","zh-cn",{abort:"\u4e0a\u4f20\u5df2\u88ab\u7528\u6237\u4e2d\u6b62\u3002",doneOne:"\u6587\u4ef6\u4e0a\u4f20\u6210\u529f\u3002",doneMany:"\u6210\u529f\u4e0a\u4f20\u4e86 %1 \u4e2a\u6587\u4ef6\u3002",uploadOne:"\u6b63\u5728\u4e0a\u4f20\u6587\u4ef6\uff08{percentage}%\uff09\u2026\u2026",uploadMany:"\u6b63\u5728\u4e0a\u4f20\u6587\u4ef6\uff0c{max} \u4e2d\u7684 {current}\uff08{percentage}%\uff09\u2026\u2026"});