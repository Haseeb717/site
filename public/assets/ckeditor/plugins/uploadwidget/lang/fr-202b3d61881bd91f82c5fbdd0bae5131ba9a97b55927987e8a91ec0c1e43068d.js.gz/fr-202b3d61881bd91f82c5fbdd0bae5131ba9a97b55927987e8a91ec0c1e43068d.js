/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","fr",{abort:"T\xe9l\xe9versement interrompu par l'utilisateur.",doneOne:"Fichier t\xe9l\xe9vers\xe9 avec succ\xe8s.",doneMany:"%1 fichiers t\xe9l\xe9vers\xe9s avec succ\xe8s.",uploadOne:"T\xe9l\xe9versement du fichier en cours ({percentage}%)...",uploadMany:"T\xe9l\xe9versement des fichiers en cours, {current} sur {max} effectu\xe9s ({percentage}%)..."});