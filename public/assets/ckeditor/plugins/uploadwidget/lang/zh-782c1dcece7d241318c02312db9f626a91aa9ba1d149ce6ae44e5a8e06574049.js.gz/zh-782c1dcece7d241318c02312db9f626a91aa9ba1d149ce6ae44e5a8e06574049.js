/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","zh",{abort:"\u4e0a\u50b3\u7531\u4f7f\u7528\u8005\u653e\u68c4\u3002",doneOne:"\u6a94\u6848\u6210\u529f\u4e0a\u50b3\u3002",doneMany:"\u6210\u529f\u4e0a\u50b3 %1 \u6a94\u6848\u3002",uploadOne:"\u6b63\u5728\u4e0a\u50b3\u6a94\u6848\uff08{percentage}%\uff09...",uploadMany:"\u6b63\u5728\u4e0a\u50b3\u6a94\u6848\uff0c{max} \u4e2d\u7684 {current} \u5df2\u5b8c\u6210\uff08{percentage}%\uff09..."});