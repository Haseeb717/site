/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","ko",{abort:"\uc0ac\uc6a9\uc790\uac00 \uc5c5\ub85c\ub4dc\ub97c \uc911\ub2e8\ud588\uc2b5\ub2c8\ub2e4.",doneOne:"\ud30c\uc77c\uc774 \uc131\uacf5\uc801\uc73c\ub85c \uc5c5\ub85c\ub4dc\ub418\uc5c8\uc2b5\ub2c8\ub2e4.",doneMany:"\ud30c\uc77c %1\uac1c\ub97c \uc131\uacf5\uc801\uc73c\ub85c \uc5c5\ub85c\ub4dc\ud558\uc600\uc2b5\ub2c8\ub2e4.",uploadOne:"\ud30c\uc77c \uc5c5\ub85c\ub4dc\uc911 ({percentage}%)...",uploadMany:"\ud30c\uc77c {max} \uac1c \uc911 {current} \ubc88\uc9f8 \ud30c\uc77c \uc5c5\ub85c\ub4dc \uc911 ({percentage}%)..."});