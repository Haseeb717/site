/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","hu",{abort:"A felt\xf6lt\xe9st a felhaszn\xe1l\xf3 megszak\xedtotta.",doneOne:"A f\xe1jl sikeresen felt\xf6ltve.",doneMany:"%1 f\xe1jl sikeresen felt\xf6ltve.",uploadOne:"F\xe1jl felt\xf6lt\xe9se ({percentage}%)...",uploadMany:"F\xe1jlok felt\xf6lt\xe9se, {current}/{max} k\xe9sz ({percentage}%)..."});