/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","eo",{abort:"Al\u015duto \u0109esigita de la uzanto",doneOne:"Dosiero sukcese al\u015dutita.",doneMany:"Sukcese al\u015dutitaj %1 dosieroj.",uploadOne:"al\u015dutata dosiero ({percentage}%)...",uploadMany:"Al\u015dutataj dosieroj, {current} el {max} faritaj ({percentage}%)..."});