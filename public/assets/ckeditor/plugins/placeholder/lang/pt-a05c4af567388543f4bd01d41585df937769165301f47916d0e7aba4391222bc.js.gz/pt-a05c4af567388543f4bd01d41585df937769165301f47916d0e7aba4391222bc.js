/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","pt",{title:"Propriedades dos marcadores",toolbar:"S\xedmbolo",name:"Nome do marcador",invalidName:"O marcador n\xe3o pode estar em branco e n\xe3o pode conter qualquer dos seguintes carateres: [, ], <, >",pathName:"s\xedmbolo"});