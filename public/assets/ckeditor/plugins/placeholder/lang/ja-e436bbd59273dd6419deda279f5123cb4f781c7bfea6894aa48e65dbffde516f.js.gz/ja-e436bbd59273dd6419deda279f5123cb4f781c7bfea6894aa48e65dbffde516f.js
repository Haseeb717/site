/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","ja",{title:"\u30d7\u30ec\u30fc\u30b9\u30db\u30eb\u30c0\u306e\u30d7\u30ed\u30d1\u30c6\u30a3",toolbar:"\u30d7\u30ec\u30fc\u30b9\u30db\u30eb\u30c0\u3092\u4f5c\u6210",name:"\u30d7\u30ec\u30fc\u30b9\u30db\u30eb\u30c0\u540d",invalidName:"\u30d7\u30ec\u30fc\u30b9\u30db\u30eb\u30c0\u306f\u7a7a\u6b04\u306b\u3067\u304d\u307e\u305b\u3093\u3002\u307e\u305f\u3001[, ], <, > \u306e\u6587\u5b57\u306f\u4f7f\u7528\u3067\u304d\u307e\u305b\u3093\u3002",pathName:"placeholder"});