/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","es",{title:"Propiedades del Marcador de Posici\xf3n",toolbar:"Crear Marcador de Posici\xf3n",name:"Nombre del Marcador de Posici\xf3n",invalidName:"El marcador de posici\xf3n no puede estar vac\xedo y no puede contener ninguno de los siguientes caracteres: [, ], <, >",pathName:"marcador de posici\xf3n"});