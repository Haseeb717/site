/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","pl",{title:"W\u0142a\u015bciwo\u015bci wype\u0142niacza",toolbar:"Utw\xf3rz wype\u0142niacz",name:"Nazwa wype\u0142niacza",invalidName:"Wype\u0142niacz nie mo\u017ce by\u0107 pusty ani nie mo\u017ce zawiera\u0107 \u017cadnego z nast\u0119puj\u0105cych znak\xf3w: [, ], < oraz >",pathName:"wype\u0142niacz"});