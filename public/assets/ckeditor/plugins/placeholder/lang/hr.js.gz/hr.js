/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","hr",{title:"Svojstva rezerviranog mjesta",toolbar:"Napravi rezervirano mjesto",name:"Ime rezerviranog mjesta",invalidName:"Rezervirano mjesto ne mo\u017ee biti prazno niti mo\u017ee sadr\u017eavati ijedan od sljede\u0107ih znakova: [, ], <, >",pathName:"rezervirano mjesto"});