/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","fr",{title:"Propri\xe9t\xe9s de l'Espace r\xe9serv\xe9",toolbar:"Cr\xe9er l'Espace r\xe9serv\xe9",name:"Nom de l'espace r\xe9serv\xe9",invalidName:"L'espace r\xe9serv\xe9 ne peut pas \xeatre vide ni contenir l'un de ses caract\xe8res : [, ], <, >",pathName:"espace r\xe9serv\xe9"});