/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","ug",{title:"\u0626\u0648\u0631\u06c7\u0646 \u0628\u06d5\u0644\u06af\u06d5 \u062e\u0627\u0633\u0644\u0649\u0642\u0649",toolbar:"\u0626\u0648\u0631\u06c7\u0646 \u0628\u06d5\u0644\u06af\u06d5 \u0642\u06c7\u0631",name:"Placeholder Name",invalidName:"The placeholder can not be empty and can not contain any of following characters: [, ], <, >",pathName:"placeholder"});