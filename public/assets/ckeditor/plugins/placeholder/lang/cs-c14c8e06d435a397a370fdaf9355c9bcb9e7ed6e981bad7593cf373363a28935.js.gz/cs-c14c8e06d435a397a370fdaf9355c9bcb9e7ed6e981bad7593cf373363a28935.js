/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","cs",{title:"Vlastnosti vyhrazen\xe9ho prostoru",toolbar:"Vytvo\u0159it vyhrazen\xfd prostor",name:"N\xe1zev vyhrazen\xe9ho prostoru",invalidName:"Vyhrazen\xfd prostor nesm\xed b\xfdt pr\xe1zdn\xfd \u010di obsahovat n\xe1sleduj\xedc\xed znaky: [, ], <, >",pathName:"Vyhrazen\xfd prostor"});