/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","nb",{title:"Egenskaper for plassholder",toolbar:"Opprett plassholder",name:"Navn p\xe5 plassholder",invalidName:"Plassholderen kan ikke v\xe6re tom, og kan ikke inneholde f\xf8lgende tegn: [, ], <, >",pathName:"plassholder"});