/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","vi",{title:"Thu\u1ed9c t\xednh \u0111\u1eb7t ch\u1ed7",toolbar:"T\u1ea1o \u0111\u1eb7t ch\u1ed7",name:"T\xean gi\u1eef ch\u1ed7",invalidName:"Gi\u1eef ch\u1ed7 kh\xf4ng th\u1ec3 \u0111\u1ec3 tr\u1ed1ng v\xe0 kh\xf4ng th\u1ec3 ch\u1ee9a b\u1ea5t k\u1ef3 k\xfd t\u1ef1 sau: [,], <, >",pathName:"gi\u1eef ch\u1ed7"});