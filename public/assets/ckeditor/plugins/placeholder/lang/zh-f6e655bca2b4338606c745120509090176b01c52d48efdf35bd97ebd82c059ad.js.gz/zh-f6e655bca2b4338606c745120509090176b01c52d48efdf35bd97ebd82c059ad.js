/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","zh",{title:"\u9810\u7559\u4f4d\u7f6e\u5c6c\u6027",toolbar:"\u5efa\u7acb\u9810\u7559\u4f4d\u7f6e",name:"Placeholder \u540d\u7a31",invalidName:"\u300c\u9810\u7559\u4f4d\u7f6e\u300d\u4e0d\u53ef\u70ba\u7a7a\u767d\u4e14\u4e0d\u53ef\u5305\u542b\u4ee5\u4e0b\u5b57\u5143\uff1a[, ], <, >",pathName:"\u9810\u7559\u4f4d\u7f6e"});