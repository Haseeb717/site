/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","ca",{title:"Propietats del marcador de posici\xf3",toolbar:"Marcador de posici\xf3",name:"Nom del marcador de posici\xf3",invalidName:"El marcador de posici\xf3 no pot estar en blanc ni pot contenir cap dels car\xe0cters seg\xfcents: [,],<,>",pathName:"marcador de posici\xf3"});