/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","it",{title:"Propriet\xe0 segnaposto",toolbar:"Crea segnaposto",name:"Nome segnaposto",invalidName:"Il segnaposto non pu\xf2 essere vuoto e non pu\xf2 contenere nessuno dei seguenti caratteri: [, ], <, >",pathName:"segnaposto"});