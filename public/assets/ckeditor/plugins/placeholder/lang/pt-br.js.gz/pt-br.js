/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","pt-br",{title:"Propriedades do Espa\xe7o Reservado",toolbar:"Criar Espa\xe7o Reservado",name:"Nome do Espa\xe7o Reservado",invalidName:"O espa\xe7o reservado n\xe3o pode estar vazio e n\xe3o pode conter nenhum dos seguintes caracteres:  [, ], <, >",pathName:"Espa\xe7o Reservado"});