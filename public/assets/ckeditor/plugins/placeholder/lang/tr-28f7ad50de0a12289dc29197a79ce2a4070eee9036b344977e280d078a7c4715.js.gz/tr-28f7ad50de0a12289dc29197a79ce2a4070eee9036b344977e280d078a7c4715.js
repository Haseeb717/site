/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","tr",{title:"Yer tutucu \xf6zellikleri",toolbar:"Yer tutucu olu\u015fturun",name:"Yer Tutucu Ad\u0131",invalidName:"Yer tutucu ad\u0131 bo\u015f b\u0131rak\u0131lamaz ve \u015fu karakterleri i\xe7eremez: [, ], <, >",pathName:"yertutucu"});