/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","ru",{button:"\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u044f\u0437\u044b\u043a\u0430",remove:"\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u044f\u0437\u044b\u043a"});