/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","ku",{button:"\u062c\u06ce\u06af\u06cc\u0631\u06a9\u0631\u062f\u0646\u06cc \u0632\u0645\u0627\u0646",remove:"\u0644\u0627\u0628\u0631\u062f\u0646\u06cc \u0632\u0645\u0627\u0646"});