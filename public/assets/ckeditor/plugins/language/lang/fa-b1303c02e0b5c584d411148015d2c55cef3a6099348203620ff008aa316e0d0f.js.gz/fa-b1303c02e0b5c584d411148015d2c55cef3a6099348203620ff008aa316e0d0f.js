/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","fa",{button:"\u062a\u0639\u06cc\u06cc\u0646 \u0632\u0628\u0627\u0646",remove:"\u062d\u0630\u0641 \u0632\u0628\u0627\u0646"});