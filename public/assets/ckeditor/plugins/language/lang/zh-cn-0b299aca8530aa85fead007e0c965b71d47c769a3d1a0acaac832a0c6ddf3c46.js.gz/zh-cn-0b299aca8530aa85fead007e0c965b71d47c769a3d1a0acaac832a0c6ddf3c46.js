/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","zh-cn",{button:"\u8bbe\u7f6e\u8bed\u8a00",remove:"\u79fb\u9664\u8bed\u8a00"});