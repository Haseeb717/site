/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","hu",{button:"Nyelv be\xe1ll\xedt\xe1sa",remove:"Nyelv elt\xe1vol\xedt\xe1sa"});