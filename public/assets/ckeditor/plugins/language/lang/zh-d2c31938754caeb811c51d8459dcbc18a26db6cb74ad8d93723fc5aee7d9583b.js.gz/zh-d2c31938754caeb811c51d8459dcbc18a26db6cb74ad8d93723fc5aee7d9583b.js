/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","zh",{button:"\u8a2d\u5b9a\u8a9e\u8a00",remove:"\u79fb\u9664\u8a9e\u8a00"});