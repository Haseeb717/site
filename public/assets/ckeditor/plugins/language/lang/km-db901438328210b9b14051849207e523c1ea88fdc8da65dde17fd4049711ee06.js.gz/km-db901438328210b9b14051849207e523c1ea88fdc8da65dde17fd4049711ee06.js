/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","km",{button:"\u1780\u17c6\u178e\u178f\u17cb\u200b\u1797\u17b6\u179f\u17b6",remove:"\u179b\u17bb\u1794\u200b\u1797\u17b6\u179f\u17b6"});