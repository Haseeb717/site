/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","tt",{button:"\u0422\u0435\u043b \u0441\u0430\u0439\u043b\u0430\u0443",remove:"\u0422\u0435\u043b\u043d\u0435 \u0431\u0435\u0442\u0435\u0440\u04af"});