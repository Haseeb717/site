/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","he",{button:"\u05e6\u05d5\u05e8 \u05e9\u05e4\u05d4",remove:"\u05d4\u05e1\u05e8 \u05e9\u05e4\u05d4"});