/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","ko",{button:"\uc5b8\uc5b4 \uc124\uc815",remove:"\uc5b8\uc5b4 \uc124\uc815 \uc9c0\uc6b0\uae30"});