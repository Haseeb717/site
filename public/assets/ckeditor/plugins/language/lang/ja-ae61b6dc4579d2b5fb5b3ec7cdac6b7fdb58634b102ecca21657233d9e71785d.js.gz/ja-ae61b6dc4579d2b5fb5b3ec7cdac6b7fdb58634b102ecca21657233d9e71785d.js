/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","ja",{button:"\u8a00\u8a9e\u3092\u8a2d\u5b9a",remove:"\u8a00\u8a9e\u3092\u524a\u9664"});