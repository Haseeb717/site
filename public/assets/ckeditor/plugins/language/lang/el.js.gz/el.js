/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","el",{button:"\u0398\u03ad\u03c3\u03b7 \u03b3\u03bb\u03ce\u03c3\u03c3\u03b1\u03c2",remove:"\u0391\u03c6\u03b1\u03af\u03c1\u03b5\u03c3\u03b7 \u03b3\u03bb\u03ce\u03c3\u03c3\u03b1\u03c2"});