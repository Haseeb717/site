/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("language","ar",{button:"\u062d\u062f\u062f \u0627\u0644\u0644\u063a\u0629",remove:"\u062d\u0630\u0641 \u0627\u0644\u0644\u063a\u0629"});