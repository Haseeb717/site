/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","lv",{move:"Klik\u0161\u0137ina un velc, lai p\u0101rvietotu"});