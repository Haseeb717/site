/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","fa",{move:"\u06a9\u0644\u06cc\u06a9 \u0648 \u06a9\u0634\u06cc\u062f\u0646 \u0628\u0631\u0627\u06cc \u062c\u0627\u0628\u062c\u0627\u06cc\u06cc"});