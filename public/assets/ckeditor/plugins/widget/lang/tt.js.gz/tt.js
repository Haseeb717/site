/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","tt",{move:"\u041a\u04af\u0447\u0435\u0440\u0435\u043f \u043a\u0443\u0435\u0440 \u04e9\u0447\u0435\u043d \u0431\u0430\u0441\u044b\u043f \u0448\u0443\u0434\u044b\u0440\u044b\u0433\u044b\u0437"});