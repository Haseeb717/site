/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","vi",{move:"Nh\u1ea5p chu\u1ed9t v\xe0 k\xe9o \u0111\u1ec3 di chuy\u1ec3n"});