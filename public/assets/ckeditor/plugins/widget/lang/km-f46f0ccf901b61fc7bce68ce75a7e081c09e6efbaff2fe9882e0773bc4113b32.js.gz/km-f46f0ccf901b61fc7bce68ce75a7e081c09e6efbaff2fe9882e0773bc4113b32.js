/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","km",{move:"\u1785\u17bb\u1785\u200b\u17a0\u17be\u1799\u200b\u1791\u17b6\u1789\u200b\u178a\u17be\u1798\u17d2\u1794\u17b8\u200b\u1795\u17d2\u179b\u17b6\u179f\u17cb\u200b\u1791\u17b8"});