/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","zh-cn",{move:"\u70b9\u51fb\u5e76\u62d6\u62fd\u4ee5\u79fb\u52a8"});