/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("widget","ku",{move:"\u06a9\u0631\u062a\u06d5\u0628\u06a9\u06d5 \u0648 \u0695\u0627\u06cc\u0628\u06a9\u06ce\u0634\u06d5 \u0628\u06c6 \u062c\u0648\u06b5\u0627\u0646\u062f\u0646"});